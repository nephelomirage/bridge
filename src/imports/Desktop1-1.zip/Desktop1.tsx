import imgStreamgraph1 from "./965f1f34698ab0e096a60f3af67ffe455ce55dfe.png";

export default function Desktop() {
  return (
    <div className="relative size-full" data-name="Desktop - 1">
      <div aria-hidden="true" className="absolute bg-white inset-0 pointer-events-none" />
      <div className="absolute h-[1024px] left-[-140px] top-0 w-[1638px]" data-name="streamgraph 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgStreamgraph1} />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_215px_70px_-26px_rgba(201,80,110,0.32)]" />
    </div>
  );
}